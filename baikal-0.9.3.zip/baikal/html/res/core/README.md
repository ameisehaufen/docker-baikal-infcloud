# Resources must be symlinked relatively to this folder
